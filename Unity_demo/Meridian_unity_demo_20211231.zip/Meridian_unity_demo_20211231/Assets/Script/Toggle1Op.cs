﻿using UnityEngine;
using UnityEngine.UI;

public class Toggle1Op : MonoBehaviour
{
    // Start is called before the first frame update
    //private GameObject parent;
    private Toggle toggle;
    private GameObject parammaster;
    private ParamMaster script;


    void Start()
    {
        toggle = GetComponent<Toggle>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnToggleChanged()
    {
        //parammaster = GameObject.Find("ParamMaster");
        //script = parammaster.GetComponent<ParamMaster>();

        if (toggle.isOn == true)
        {
            for (int i = 0; i < 15; i++)
            {
                ParamMaster.ServoCommandL_s[i] = 1;//
                ParamMaster.ServoCommandR_s[i] = 1;//
            }

            Debug.Log("toggle on");
        }
        else
        {
            for (int i = 0; i < 15; i++)
            {
                ParamMaster.ServoCommandL_s[i] = 0;//
                ParamMaster.ServoCommandR_s[i] = 0;//
            }
            Debug.Log("toggle off");
        }

    }
}