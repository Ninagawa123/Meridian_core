#if ENABLE_WINMD_SUPPORT

// WARNING: Do not modify! Generated file.

struct WindowsRuntimeWorkaround
{
    private Windows.Foundation.IAsyncAction _workaroundAction;
}

#endif
