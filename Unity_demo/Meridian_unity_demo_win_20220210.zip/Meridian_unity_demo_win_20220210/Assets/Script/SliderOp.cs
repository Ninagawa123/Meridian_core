﻿using UnityEngine;
using UnityEngine.UI;
using System;

// サーボ操作GUIパネルのスライダーに入力された数値を、ParamMasterに送る
public class SliderOp : MonoBehaviour
{
    private GameObject parent;
    private int servoNum;

    private Slider slider;
    private string lR;

    void Start()
    {
        //parammaster = GameObject.Find("ParamMaster");
        slider = GetComponent<Slider>();
        parent = transform.parent.gameObject;
        servoNum = Convert.ToInt32(parent.name.Substring(1, 2));
        lR = parent.name.Substring(0, 1);
    }

    void FixedUpdate()
    {
        //script = parammaster.GetComponent<ParamMaster>();
        if (lR == "L")
        {
            if (ParamMaster.ServoCommandL_s[servoNum] == 0)//サーボコマンドが0ならばパラムマスターの値を反映
            {
                slider.value = ParamMaster.ServoAnglesL_diff[servoNum];
                //ParamMaster.ServoAnglesL_UI[servoNum] = slider.value;
            }
            else
            {
                //slider.value = ParamMaster.ServoAnglesL_diff[servoNum];
            }
        }
        else
        {
            if (ParamMaster.ServoCommandR_s[servoNum] == 0)//サーボコマンドが0ならばパラムマスターの値を反映
            {
                slider.value = ParamMaster.ServoAnglesR_diff[servoNum];
            }
            else
            {
                //slider.value = ParamMaster.ServoAnglesL_diff[servoNum];
            }
        }
    }

    void Update()
    {

    }

    public void SlidernewValue(float newValue)
    {
        if (lR == "L")
        {
            ParamMaster.ServoAnglesL_UI[servoNum] = newValue;
            //slider.value = script.ServoAnglesL[servoNum];
        }
        else
        {
            ParamMaster.ServoAnglesR_UI[servoNum] = newValue;
            //slider.value = script.ServoAnglesR[servoNum];

        }
    }
}