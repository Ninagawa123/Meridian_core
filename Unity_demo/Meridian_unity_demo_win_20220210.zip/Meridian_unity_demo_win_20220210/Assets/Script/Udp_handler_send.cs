﻿//meridian_20211231_unity_udp_handler.cs
using UnityEngine;
using System.Net.Sockets;
using System;

public class Udp_handler_send : MonoBehaviour //UDP送信用

{
    const string HOST = "192.168.1.xx";//送信先(ESP32)のIPアドレス
    const int SEND_PORT = 22224;//送信用ポート設定
    static UdpClient udp_send;//UDP送信を使う準備

    const int MSG_SIZE = 90;//送受信するshort型データの個数
    public int[] r_meridim_monitor = new int[MSG_SIZE];//受信データインスペクタ表示用

    static byte[] s_packet_byte = new byte[MSG_SIZE * 2];//データ送信用のchar型変数（１バイト）
    static short[] s_packet_short = new short[MSG_SIZE];//データ送信格納用のshort型変数（２バイト）
    public int[] s_meridim_monitor = new int[MSG_SIZE];//送信データインスペクタ表示用

    void Start()
    {
        //FixedUpdateの間隔はreceiveで設定

        //UDP関連の諸設定
        udp_send = new UdpClient();
        udp_send.Connect(HOST, SEND_PORT);
    }


    void FixedUpdate()//UDP受信データをPramMasterに反映
    {

        //<1-4>送信データのparamMasterからのs_meridim反映処理
        for (int i = 0; i < 15; i++)
        {
            ParamMaster.s_meridim[i * 2 + 21] = (short)Mathf.Round(ParamMaster.ServoAnglesL[i] * 100);
            ParamMaster.s_meridim[i * 2 + 51] = (short)Mathf.Round(ParamMaster.ServoAnglesR[i] * 100);
        }

        //[2] UDP送信処理
        senddataUDP();//毎フレームデータを送信してみる
    }

    void Update()//UDP送信データをインスペクターに反映
    {
        for (int i = 0; i < MSG_SIZE; i++)
        {
            s_meridim_monitor[i] = s_packet_short[i];//受信データをインスペクター表示用配列に転記
        }
    }


    void OnApplicationQuit()//アプリ終了時の処理.
    {
        udp_send.Close();//UDPの送信を終了
    }

    public void senddataUDP()//送信データの作成と送信
    {
        //[1]
        //<1-1>s_packet_shortにs_meridimを転記
        for (int i = 0; i < MSG_SIZE; i++)
        {
            s_packet_short[i] = ParamMaster.s_meridim[i];
        }

        //<1-2>トグルスイッチのオンオフ（サーボをUnityから動作させるかどうか）を取得
        for (int i = 0; i < 15; i++)
        {
            s_packet_short[(i * 2) + 20] = (short)(ParamMaster.ServoCommandL_s[i]);//受信サーボコマンドのParamserver反映
            s_packet_short[(i * 2) + 50] = (short)(ParamMaster.ServoCommandR_s[i]);//受信サーボコマンドのParamserver反映
        }

        //[2]送信データを作成
        //<2-1>チェックサムの作成
        int checksum = 0;
        for (int i = 0; i < MSG_SIZE - 1; i++)
        {
            checksum += s_packet_short[i];
        }
        checksum = ~checksum;
        s_packet_short[MSG_SIZE - 1] = (short)checksum;

        //<2-2>ショート型をバイトに変換
        for (int i = 0; i < MSG_SIZE; i++)
        {
            byte[] byteArray = BitConverter.GetBytes(s_packet_short[i]);
            s_packet_byte[i * 2] = (byte)byteArray[0];
            s_packet_byte[i * 2 + 1] = (byte)byteArray[1];
            //<2-3>送信データをインスペクタ表示用配列に反映
            s_meridim_monitor[i] = s_packet_short[i];
        }

        //[3]送信を実行
        udp_send.Send(s_packet_byte, MSG_SIZE * 2);
    }
}